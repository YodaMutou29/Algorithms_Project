# Algorithms_Project
Compile Instructions
  Windows: g++ main.cpp Node.cpp RedBlackTree.cpp -o RedBlack.exe
  Linux: g++ -o RedBlack main.cpp Node.cpp RedBlackTree.cpp

Running Instructions:
  Windows: RedBlack.exe
  Linux: ./RedBlack
